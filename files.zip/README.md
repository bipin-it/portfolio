# Bipin Khanal — Portfolio

A personal portfolio site: profile, skills, projects, and a working contact form.

## Structure

```
portfolio/
├── index.html              Main page (all sections)
├── style.css                Styling ("blueprint / schematic" theme)
├── script.js                 Nav toggle, hero animation, form validation + submit
├── server.js                  Express backend (serves the site + /api/contact)
├── package.json
├── data/submissions.json      Contact form messages get appended here
├── assets/                    Put profile-photo.jpg here (see below)
└── projects/
    ├── calculator/index.html    Working calculator demo
    └── todo-list/index.html     Working to-do list demo
```

## Running it locally

Requires [Node.js](https://nodejs.org/) (v18+ recommended).

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

The contact form posts to `/api/contact`, which validates the input, applies
basic rate limiting and honeypot spam protection, and appends the message to
`data/submissions.json`. If you open `index.html` directly as a file (without
running `server.js`), the contact form will show a "couldn't reach the
server" message — that's expected, since there's no backend to receive it.

## Before you publish this, replace the placeholders

- **Photo:** add a real photo as `assets/profile-photo.jpg` (square image,
  at least 400×400px works well). Until then, a placeholder box is shown.
- **Email / GitHub / LinkedIn:** in `index.html`, search for
  `bipin.khanal@example.com` and the `github.com/bipinkhanal` /
  `linkedin.com/in/bipinkhanal` links in the Contact section, and swap in
  your real ones.
- **Third project card:** the "Your Next Project" card in the Projects
  section is a placeholder — replace it with a real project, or remove it.
- **Project source links:** the "Source code →" links currently point to
  `#`. Point them at your GitHub repos once the code is pushed there.

## Possible next steps (optional)

These are suggestions, not requirements — pick what's useful:

- Swap the `data/submissions.json` file for a small database (SQLite is a
  good next step) if you expect a lot of submissions.
- Wire up email notifications for new messages using a package like
  [Nodemailer](https://nodemailer.com/) — a commented-out starting point is
  already in `server.js`.
- Deploy the site (e.g. Render, Railway, or a VPS) so it's reachable outside
  your own machine. Static hosts like Netlify/Vercel won't run `server.js`
  directly — you'd need their serverless functions, or a host that runs
  Node processes.
- Add a resume/CV download link near the top of the Profile section.
